"use client"

import PixelCanvas from "../pixel-canvas"

export default function Page() {
  return <PixelCanvas />
}
