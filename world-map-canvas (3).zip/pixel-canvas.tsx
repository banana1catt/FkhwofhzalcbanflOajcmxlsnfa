"use client"

import type React from "react"

import { useRef, useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Send,
  MessageCircle,
  X,
  Home,
  Settings,
  Palette,
  Navigation,
  ZoomIn,
  ZoomOut,
  Trash2,
  Download,
  Users,
  Wifi,
} from "lucide-react"

interface ChatMessage {
  id: string
  text: string
  timestamp: number
  user: string
  userId: string
  type: "message" | "system" | "paint"
}

interface OnlineUser {
  id: string
  name: string
  color: string
  lastSeen: number
  isActive: boolean
}

interface PixelUpdate {
  x: number
  y: number
  color: string
  user: string
  userId: string
  timestamp: number
}

interface SharedState {
  pixels: Record<string, string>
  messages: ChatMessage[]
  users: OnlineUser[]
  lastUpdate: number
}

export default function PixelCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const chatScrollRef = useRef<HTMLDivElement>(null)

  // State variables
  const [color, setColor] = useState("#ff0000")
  const [scale, setScale] = useState(1)
  const [offsetX, setOffsetX] = useState(0)
  const [offsetY, setOffsetY] = useState(0)
  const [isPainting, setIsPainting] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [isZooming, setIsZooming] = useState(false)
  const [cooldownActive, setCooldownActive] = useState(false)
  const [paintedPixels, setPaintedPixels] = useState<Map<string, string>>(new Map())
  const [paintMode, setPaintMode] = useState(false)

  // Multiplayer state
  const [currentUser, setCurrentUser] = useState<OnlineUser>(() => {
    const userId = "user-" + Math.random().toString(36).substr(2, 9)
    return {
      id: userId,
      name: `Kullanıcı${Math.floor(Math.random() * 1000)}`,
      color: "#ff0000",
      lastSeen: Date.now(),
      isActive: true,
    }
  })
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([])
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [recentPixelUpdates, setRecentPixelUpdates] = useState<PixelUpdate[]>([])

  // UI State
  const [chatOpen, setChatOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [colorPaletteOpen, setColorPaletteOpen] = useState(false)
  const [usersListOpen, setUsersListOpen] = useState(false)
  const [newMessage, setNewMessage] = useState("")

  // Constants
  const canvasWidth = 4096
  const canvasHeight = 4096
  const minScale = 0.01 // Much smaller minimum for 4K canvas
  const maxScale = 20
  const cooldownTime = 100
  const brushSize = 1
  // Use real devicePixelRatio in the browser, fall back to 1 on the server
  const PIXEL_RATIO = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1
  const STORAGE_KEY = "pixel-canvas-shared-state"
  const USER_HEARTBEAT_INTERVAL = 2000
  const STATE_SYNC_INTERVAL = 500

  // Predefined color palette
  const colorPalette = [
    "#000000",
    "#FFFFFF",
    "#FF0000",
    "#00FF00",
    "#0000FF",
    "#FFFF00",
    "#FF00FF",
    "#00FFFF",
    "#800000",
    "#008000",
    "#000080",
    "#808000",
    "#800080",
    "#008080",
    "#C0C0C0",
    "#808080",
    "#FF8080",
    "#80FF80",
    "#8080FF",
    "#FFFF80",
    "#FF80FF",
    "#80FFFF",
    "#FFA500",
    "#A52A2A",
    "#DDA0DD",
    "#98FB98",
    "#F0E68C",
    "#DEB887",
    "#D2691E",
    "#FF69B4",
    "#CD5C5C",
    "#4B0082",
  ]

  // Touch handling refs
  const touchStartRef = useRef<{ x: number; y: number; distance: number; time: number }>({
    x: 0,
    y: 0,
    distance: 0,
    time: 0,
  })
  const dragStartRef = useRef({ x: 0, y: 0 })
  const dragOffsetRef = useRef({ x: 0, y: 0 })
  const lastClickTimeRef = useRef(0)
  const backgroundImageRef = useRef<HTMLImageElement | null>(null)
  const lastSyncTimeRef = useRef(0)

  // Shared state management functions
  const getSharedState = useCallback((): SharedState => {
    // During the build (server) there is no localStorage - return a blank state
    if (typeof window === "undefined") {
      return {
        pixels: {},
        messages: [],
        users: [],
        lastUpdate: Date.now(),
      }
    }

    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) return JSON.parse(stored)
    } catch (err) {
      console.error("Error reading shared state:", err)
    }
    return {
      pixels: {},
      messages: [],
      users: [],
      lastUpdate: Date.now(),
    }
  }, [])

  const updateSharedState = useCallback(
    (updater: (state: SharedState) => SharedState) => {
      try {
        const currentState = getSharedState()
        const newState = updater(currentState)
        newState.lastUpdate = Date.now()
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newState))

        // Trigger storage event for other tabs
        window.dispatchEvent(new StorageEvent("storage", { key: STORAGE_KEY }))
      } catch (error) {
        console.error("Error updating shared state:", error)
      }
    },
    [getSharedState],
  )

  // Sync local state with shared state
  const syncWithSharedState = useCallback(() => {
    const sharedState = getSharedState()

    // Only sync if there are actual changes
    if (sharedState.lastUpdate <= lastSyncTimeRef.current) {
      return
    }

    lastSyncTimeRef.current = sharedState.lastUpdate

    // Update pixels
    const newPixels = new Map<string, string>()
    Object.entries(sharedState.pixels).forEach(([key, color]) => {
      newPixels.set(key, color)
    })
    setPaintedPixels(newPixels)

    // Update messages
    setChatMessages(sharedState.messages)

    // Update users (excluding current user)
    const otherUsers = sharedState.users.filter((user) => user.id !== currentUser.id)
    setOnlineUsers(otherUsers)

    // Auto-scroll chat to bottom if new messages
    setTimeout(() => {
      if (chatScrollRef.current) {
        chatScrollRef.current.scrollTop = chatScrollRef.current.scrollTop + 1000
      }
    }, 100)
  }, [getSharedState, currentUser.id])

  // Update user heartbeat
  const updateUserHeartbeat = useCallback(() => {
    updateSharedState((state) => {
      const updatedUsers = state.users.filter((user) => user.id !== currentUser.id)
      const updatedCurrentUser = { ...currentUser, lastSeen: Date.now(), isActive: true }

      return {
        ...state,
        users: [...updatedUsers, updatedCurrentUser],
      }
    })
  }, [updateSharedState, currentUser])

  // Clean up inactive users
  const cleanupInactiveUsers = useCallback(() => {
    const now = Date.now()
    updateSharedState((state) => ({
      ...state,
      users: state.users.filter((user) => now - user.lastSeen < 10000), // Remove users inactive for 10 seconds
    }))
  }, [updateSharedState])

  // Send chat message
  const sendChatMessage = useCallback(
    (text: string, type: "message" | "system" | "paint" = "message") => {
      const message: ChatMessage = {
        id: Date.now().toString() + "-" + Math.random().toString(36).substr(2, 5),
        text,
        timestamp: Date.now(),
        user: currentUser.name,
        userId: currentUser.id,
        type,
      }

      updateSharedState((state) => ({
        ...state,
        messages: [...state.messages.slice(-50), message], // Keep last 50 messages
      }))
    },
    [updateSharedState, currentUser],
  )

  // Paint pixel and sync
  const paintPixelSync = useCallback(
    (x: number, y: number, color: string) => {
      const pixelKey = `${x},${y}`

      // Update local state immediately for responsiveness
      setPaintedPixels((prev) => {
        const newPixels = new Map(prev)
        newPixels.set(pixelKey, color)
        return newPixels
      })

      // Update shared state
      updateSharedState((state) => ({
        ...state,
        pixels: {
          ...state.pixels,
          [pixelKey]: color,
        },
      }))

      // Add to recent updates for animation
      const pixelUpdate: PixelUpdate = {
        x,
        y,
        color,
        user: currentUser.name,
        userId: currentUser.id,
        timestamp: Date.now(),
      }
      setRecentPixelUpdates((prev) => [...prev.slice(-20), pixelUpdate])
    },
    [updateSharedState, currentUser],
  )

  // Load background image
  useEffect(() => {
    const img = new Image()
    img.crossOrigin = "anonymous"

    img.onload = () => {
      backgroundImageRef.current = img
      resetView()
    }

    img.onerror = () => {
      console.warn("Background image not found, using white background")
      const tempCanvas = document.createElement("canvas")
      tempCanvas.width = canvasWidth
      tempCanvas.height = canvasHeight
      const tempCtx = tempCanvas.getContext("2d")
      if (tempCtx) {
        tempCtx.fillStyle = "#ffffff"
        tempCtx.fillRect(0, 0, canvasWidth, canvasHeight)

        const whiteImg = new Image()
        whiteImg.onload = () => {
          backgroundImageRef.current = whiteImg
          resetView()
        }
        whiteImg.src = tempCanvas.toDataURL()
      }
    }

    img.src = "/world-map-4k.png"
  }, [])

  // Initialize multiplayer system
  useEffect(() => {
    // Initial sync
    syncWithSharedState()

    // Send join message
    setTimeout(() => {
      sendChatMessage(`${currentUser.name} haritaya katıldı! 👋`, "system")
    }, 1000)

    // Set up intervals
    const heartbeatInterval = setInterval(updateUserHeartbeat, USER_HEARTBEAT_INTERVAL)
    const syncInterval = setInterval(syncWithSharedState, STATE_SYNC_INTERVAL)
    const cleanupInterval = setInterval(cleanupInactiveUsers, 5000)

    // Listen for storage changes from other tabs
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) {
        syncWithSharedState()
      }
    }

    window.addEventListener("storage", handleStorageChange)

    // Cleanup on unmount
    return () => {
      clearInterval(heartbeatInterval)
      clearInterval(syncInterval)
      clearInterval(cleanupInterval)
      window.removeEventListener("storage", handleStorageChange)

      // Send leave message
      sendChatMessage(`${currentUser.name} haritadan ayrıldı! 👋`, "system")
    }
  }, [syncWithSharedState, updateUserHeartbeat, cleanupInactiveUsers, sendChatMessage, currentUser.name])

  const resetView = useCallback(() => {
    if (!containerRef.current) return

    // Calculate scale to fit the entire 4K canvas with some padding
    const scaleX = (window.innerWidth * 0.9) / canvasWidth
    const scaleY = (window.innerHeight * 0.9) / canvasHeight
    const newScale = Math.min(scaleX, scaleY)

    const newOffsetX = (window.innerWidth - canvasWidth * newScale) / 2
    const newOffsetY = (window.innerHeight - canvasHeight * newScale) / 2

    setScale(newScale)
    setOffsetX(newOffsetX)
    setOffsetY(newOffsetY)

    redrawCanvas(newScale, newOffsetX, newOffsetY)
  }, [])

  const redrawCanvas = useCallback(
    (currentScale = scale, currentOffsetX = offsetX, currentOffsetY = offsetY) => {
      const canvas = canvasRef.current
      const ctx = canvas?.getContext("2d")
      if (!canvas || !ctx || !backgroundImageRef.current) return

      const displayWidth = window.innerWidth
      const displayHeight = window.innerHeight

      canvas.width = displayWidth * PIXEL_RATIO
      canvas.height = displayHeight * PIXEL_RATIO
      canvas.style.width = displayWidth + "px"
      canvas.style.height = displayHeight + "px"

      ctx.scale(PIXEL_RATIO, PIXEL_RATIO)
      ctx.imageSmoothingEnabled = false

      ctx.clearRect(0, 0, displayWidth, displayHeight)
      ctx.save()

      ctx.translate(currentOffsetX, currentOffsetY)
      ctx.scale(currentScale, currentScale)

      ctx.drawImage(backgroundImageRef.current, 0, 0, canvasWidth, canvasHeight)

      // Draw painted pixels
      paintedPixels.forEach((color, key) => {
        const [x, y] = key.split(",").map(Number)
        ctx.fillStyle = color
        ctx.fillRect(x, y, 1, 1)
      })

      // Draw recent pixel updates with animation
      const now = Date.now()
      recentPixelUpdates.forEach((update) => {
        const age = now - update.timestamp
        if (age < 2000) {
          // Show for 2 seconds
          const alpha = Math.max(0, 1 - age / 2000)
          ctx.save()
          ctx.globalAlpha = alpha
          ctx.strokeStyle = update.userId === currentUser.id ? "#00ff00" : "#ffffff"
          ctx.lineWidth = 2 / currentScale
          ctx.strokeRect(update.x - 0.5, update.y - 0.5, 2, 2)
          ctx.restore()
        }
      })

      if (currentScale >= 4) {
        drawGrid(ctx, currentScale)
      }

      ctx.restore()
    },
    [scale, offsetX, offsetY, paintedPixels, recentPixelUpdates, currentUser.id],
  )

  const drawGrid = (ctx: CanvasRenderingContext2D, currentScale: number) => {
    ctx.strokeStyle = `rgba(0,0,0,${Math.min(0.2, currentScale / 30)})`
    ctx.lineWidth = 1 / currentScale

    const startX = Math.max(0, Math.floor(-offsetX / currentScale))
    const endX = Math.min(canvasWidth, Math.ceil((window.innerWidth - offsetX) / currentScale))
    const startY = Math.max(0, Math.floor(-offsetY / currentScale))
    const endY = Math.min(canvasHeight, Math.ceil((window.innerHeight - offsetY) / currentScale))

    for (let x = startX; x <= endX; x += 1) {
      ctx.beginPath()
      ctx.moveTo(x, startY)
      ctx.lineTo(x, endY)
      ctx.stroke()
    }

    for (let y = startY; y <= endY; y += 1) {
      ctx.beginPath()
      ctx.moveTo(startX, y)
      ctx.lineTo(endX, y)
      ctx.stroke()
    }
  }

  const zoomToPoint = useCallback(
    (clientX: number, clientY: number, newScale: number) => {
      // Smooth zoom without snapping to predefined levels
      newScale = Math.max(minScale, Math.min(maxScale, newScale))

      const pointX = Math.round((clientX - offsetX) / scale)
      const pointY = Math.round((clientY - offsetY) / scale)

      const newOffsetX = Math.round(clientX - pointX * newScale)
      const newOffsetY = Math.round(clientY - pointY * newScale)

      setScale(newScale)
      setOffsetX(newOffsetX)
      setOffsetY(newOffsetY)

      redrawCanvas(newScale, newOffsetX, newOffsetY)
    },
    [scale, offsetX, offsetY, redrawCanvas],
  )

  const paintPixel = useCallback(
    (canvasX: number, canvasY: number) => {
      if (!paintMode) return
      if (canvasX < 0 || canvasX >= canvasWidth || canvasY < 0 || canvasY >= canvasHeight) return

      const now = Date.now()
      if (now - lastClickTimeRef.current < cooldownTime) return

      lastClickTimeRef.current = now
      setCooldownActive(true)

      setTimeout(() => {
        setCooldownActive(false)
      }, cooldownTime)

      const halfSize = Math.floor(brushSize / 2)

      for (let x = -halfSize; x <= halfSize; x++) {
        for (let y = -halfSize; y <= halfSize; y++) {
          const px = Math.floor(canvasX) + x
          const py = Math.floor(canvasY) + y

          if (px >= 0 && px < canvasWidth && py >= 0 && py < canvasHeight) {
            paintPixelSync(px, py, color)
          }
        }
      }
    },
    [color, brushSize, paintMode, paintPixelSync],
  )

  // Event handlers (keeping the same touch/mouse logic)
  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      e.preventDefault()

      if (e.touches.length === 1) {
        const touch = e.touches[0]
        const now = Date.now()
        touchStartRef.current = { x: touch.clientX, y: touch.clientY, distance: 0, time: now }

        if (paintMode) {
          setIsPainting(true)
          const canvasX = (touch.clientX - offsetX) / scale
          const canvasY = (touch.clientY - offsetY) / scale
          paintPixel(canvasX, canvasY)
        } else {
          setIsDragging(true)
          dragStartRef.current = { x: touch.clientX, y: touch.clientY }
          dragOffsetRef.current = { x: offsetX, y: offsetY }
        }
      } else if (e.touches.length === 2) {
        setIsZooming(true)
        setIsDragging(false)
        setIsPainting(false)

        const touch1 = e.touches[0]
        const touch2 = e.touches[1]
        const distance = Math.hypot(touch2.clientX - touch1.clientX, touch2.clientY - touch1.clientY)

        touchStartRef.current = {
          x: (touch1.clientX + touch2.clientX) / 2,
          y: (touch1.clientY + touch2.clientY) / 2,
          distance: distance,
          time: Date.now(),
        }
      }
    },
    [offsetX, offsetY, scale, paintPixel, paintMode],
  )

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      e.preventDefault()

      if (e.touches.length === 1 && !isZooming) {
        const touch = e.touches[0]
        const moveDistance = Math.hypot(
          touch.clientX - touchStartRef.current.x,
          touch.clientY - touchStartRef.current.y,
        )

        if (moveDistance > 10) {
          if (paintMode && isPainting) {
            const canvasX = (touch.clientX - offsetX) / scale
            const canvasY = (touch.clientY - offsetY) / scale
            paintPixel(canvasX, canvasY)
          } else if (!paintMode && isDragging) {
            const dx = touch.clientX - dragStartRef.current.x
            const dy = touch.clientY - dragStartRef.current.y

            const newOffsetX = dragOffsetRef.current.x + dx
            const newOffsetY = dragOffsetRef.current.y + dy

            setOffsetX(newOffsetX)
            setOffsetY(newOffsetY)
            redrawCanvas(scale, newOffsetX, newOffsetY)
          }
        }
      } else if (e.touches.length === 2 && isZooming) {
        const touch1 = e.touches[0]
        const touch2 = e.touches[1]
        const distance = Math.hypot(touch2.clientX - touch1.clientX, touch2.clientY - touch1.clientY)

        const centerX = (touch1.clientX + touch2.clientX) / 2
        const centerY = (touch1.clientY + touch2.clientY) / 2

        if (touchStartRef.current.distance > 0) {
          const scaleChange = distance / touchStartRef.current.distance
          const newScale = scale * scaleChange
          zoomToPoint(centerX, centerY, newScale)
        }

        touchStartRef.current.distance = distance
      }
    },
    [isDragging, isPainting, isZooming, scale, redrawCanvas, paintPixel, zoomToPoint, paintMode],
  )

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    e.preventDefault()

    if (e.touches.length < 2) {
      setIsZooming(false)
      touchStartRef.current.distance = 0
    }

    if (e.touches.length === 0) {
      setIsDragging(false)
      setIsPainting(false)
    }
  }, [])

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      if (e.button !== 0) return

      if (paintMode) {
        setIsPainting(true)
        const canvasX = (e.clientX - offsetX) / scale
        const canvasY = (e.clientY - offsetY) / scale
        paintPixel(canvasX, canvasY)
      } else {
        setIsDragging(true)
        dragStartRef.current = { x: e.clientX, y: e.clientY }
        dragOffsetRef.current = { x: offsetX, y: offsetY }
      }
    },
    [offsetX, offsetY, scale, paintPixel, paintMode],
  )

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (isDragging && !paintMode) {
        const dx = e.clientX - dragStartRef.current.x
        const dy = e.clientY - dragStartRef.current.y

        const newOffsetX = dragOffsetRef.current.x + dx
        const newOffsetY = dragOffsetRef.current.y + dy

        setOffsetX(newOffsetX)
        setOffsetY(newOffsetY)
        redrawCanvas(scale, newOffsetX, newOffsetY)
      } else if (isPainting && paintMode) {
        const canvasX = (e.clientX - offsetX) / scale
        const canvasY = (e.clientY - offsetY) / scale
        paintPixel(canvasX, canvasY)
      }
    },
    [isDragging, isPainting, scale, offsetX, offsetY, paintPixel, redrawCanvas, paintMode],
  )

  const handleWheel = useCallback(
    (e: React.WheelEvent) => {
      e.preventDefault()
      // More sensitive and smooth zoom
      const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1
      const newScale = scale * zoomFactor
      zoomToPoint(e.clientX, e.clientY, newScale)
    },
    [scale, zoomToPoint],
  )

  // Chat functions
  const sendMessage = useCallback(() => {
    if (!newMessage.trim()) return

    sendChatMessage(newMessage)
    setNewMessage("")
  }, [newMessage, sendChatMessage])

  const downloadCanvas = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = "multiplayer-world-map.png"
    link.href = canvas.toDataURL("image/png")
    link.click()
  }, [])

  // Update current user name
  const updateUserName = useCallback(
    (newName: string) => {
      setCurrentUser((prev) => {
        const updated = { ...prev, name: newName }
        updateUserHeartbeat()
        return updated
      })
    },
    [updateUserHeartbeat],
  )

  // Initialize canvas and handle resize
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const handleResize = () => {
      redrawCanvas()
    }

    const handleGlobalMouseUp = () => {
      setIsDragging(false)
      setIsPainting(false)
    }

    window.addEventListener("resize", handleResize)
    window.addEventListener("mouseup", handleGlobalMouseUp)

    return () => {
      window.removeEventListener("resize", handleResize)
      window.removeEventListener("mouseup", handleGlobalMouseUp)
    }
  }, [redrawCanvas])

  useEffect(() => {
    redrawCanvas()
  }, [redrawCanvas])

  // Clean up old pixel updates
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now()
      setRecentPixelUpdates((prev) => prev.filter((update) => now - update.timestamp < 2000))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed inset-0 bg-gray-900 overflow-hidden select-none">
      {/* Full Screen Canvas */}
      <div
        ref={containerRef}
        className={`absolute inset-0 ${paintMode ? "cursor-crosshair" : "cursor-grab active:cursor-grabbing"}`}
        style={{ imageRendering: "pixelated" }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onWheel={handleWheel}
      >
        <canvas ref={canvasRef} className="absolute inset-0" style={{ imageRendering: "pixelated" }} />
      </div>

      {/* Top Left Controls */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
        <div className="flex gap-2">
          <Button
            onClick={() => setPaintMode(false)}
            variant={!paintMode ? "default" : "secondary"}
            size="sm"
            className={`${!paintMode ? "bg-blue-600 hover:bg-blue-700" : "bg-gray-700 hover:bg-gray-600"} text-white`}
          >
            <Navigation className="w-4 h-4 mr-1" />
            Gezinme
          </Button>
          <Button
            onClick={() => setPaintMode(true)}
            variant={paintMode ? "default" : "secondary"}
            size="sm"
            className={`${paintMode ? "bg-green-600 hover:bg-green-700" : "bg-gray-700 hover:bg-gray-600"} text-white`}
          >
            <Palette className="w-4 h-4 mr-1" />
            Boyama
          </Button>
        </div>
      </div>

      {/* Top Right Controls */}
      <div className="absolute top-4 right-4 flex gap-2 z-10">
        <Button
          onClick={() => setUsersListOpen(!usersListOpen)}
          variant="secondary"
          size="sm"
          className="bg-gray-700 hover:bg-gray-600 text-white relative"
        >
          <Users className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {onlineUsers.length + 1}
          </span>
        </Button>
        <Button
          onClick={() => setColorPaletteOpen(!colorPaletteOpen)}
          variant="secondary"
          size="sm"
          className="bg-gray-700 hover:bg-gray-600 text-white"
        >
          <Palette className="w-4 h-4" />
        </Button>
        <Button
          onClick={() => setSettingsOpen(!settingsOpen)}
          variant="secondary"
          size="sm"
          className="bg-gray-700 hover:bg-gray-600 text-white"
        >
          <Settings className="w-4 h-4" />
        </Button>
        <Button
          onClick={() => setChatOpen(!chatOpen)}
          variant="secondary"
          size="sm"
          className="bg-gray-700 hover:bg-gray-600 text-white relative"
        >
          <MessageCircle className="w-4 h-4" />
          {chatMessages.length > 1 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-2 h-2"></span>
          )}
        </Button>
      </div>

      {/* Bottom Left - Zoom Controls */}
      <div className="absolute bottom-4 left-4 flex flex-col gap-2 z-10">
        <Button
          onClick={() => zoomToPoint(window.innerWidth / 2, window.innerHeight / 2, scale * 2)}
          variant="secondary"
          size="sm"
          className="bg-gray-700 hover:bg-gray-600 text-white"
        >
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button
          onClick={() => zoomToPoint(window.innerWidth / 2, window.innerHeight / 2, scale * 0.5)}
          variant="secondary"
          size="sm"
          className="bg-gray-700 hover:bg-gray-600 text-white"
        >
          <ZoomOut className="w-4 h-4" />
        </Button>
        <Button onClick={resetView} variant="secondary" size="sm" className="bg-gray-700 hover:bg-gray-600 text-white">
          <Home className="w-4 h-4" />
        </Button>
      </div>

      {/* Bottom Center - Status */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-10">
        <div
          className={`px-4 py-2 rounded-lg text-white font-medium text-sm flex items-center gap-2 ${
            cooldownActive ? "bg-red-600" : paintMode ? "bg-green-600" : "bg-blue-600"
          }`}
        >
          <Wifi className="w-4 h-4" />
          {cooldownActive ? "Bekleyin..." : paintMode ? "Boyama Modu" : "Gezinme Modu"} | Zoom:{" "}
          {Math.round(scale * 100)}% | Online: {onlineUsers.length + 1}
        </div>
      </div>

      {/* Online Users Panel */}
      {usersListOpen && (
        <div className="absolute top-16 right-4 bg-gray-800 rounded-lg p-4 z-20 shadow-xl w-64">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-medium">Online Kullanıcılar ({onlineUsers.length + 1})</h3>
            <Button
              onClick={() => setUsersListOpen(false)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-gray-700"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="space-y-2">
            {/* Current user */}
            <div className="flex items-center gap-2 p-2 bg-gray-700 rounded">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: currentUser.color }}></div>
              <span className="text-white text-sm font-medium">{currentUser.name} (Sen)</span>
              <div className="w-2 h-2 bg-green-500 rounded-full ml-auto"></div>
            </div>
            {/* Other users */}
            {onlineUsers.map((user) => (
              <div key={user.id} className="flex items-center gap-2 p-2 bg-gray-700 rounded">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: user.color }}></div>
                <span className="text-white text-sm">{user.name}</span>
                <div className="w-2 h-2 bg-green-500 rounded-full ml-auto"></div>
              </div>
            ))}
          </div>
          <div className="mt-3 text-xs text-gray-400">💡 Yeni sekme açarak çoklu kullanıcı test edebilirsiniz!</div>
        </div>
      )}

      {/* Color Palette Panel */}
      {colorPaletteOpen && (
        <div className="absolute top-16 right-4 bg-gray-800 rounded-lg p-4 z-20 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-medium">Renk Paleti</h3>
            <Button
              onClick={() => setColorPaletteOpen(false)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-gray-700"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-8 gap-1 mb-3">
            {colorPalette.map((paletteColor) => (
              <button
                key={paletteColor}
                onClick={() => {
                  setColor(paletteColor)
                  setCurrentUser((prev) => ({ ...prev, color: paletteColor }))
                }}
                className={`w-6 h-6 rounded border-2 ${color === paletteColor ? "border-white" : "border-gray-600"}`}
                style={{ backgroundColor: paletteColor }}
              />
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-white text-sm">Özel:</span>
            <input
              type="color"
              value={color}
              onChange={(e) => {
                setColor(e.target.value)
                setCurrentUser((prev) => ({ ...prev, color: e.target.value }))
              }}
              className="w-8 h-8 rounded border border-gray-600"
            />
          </div>
        </div>
      )}

      {/* Settings Panel */}
      {settingsOpen && (
        <div className="absolute top-16 right-4 bg-gray-800 rounded-lg p-4 z-20 shadow-xl w-64">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-medium">Ayarlar</h3>
            <Button
              onClick={() => setSettingsOpen(false)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-gray-700"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-white text-sm mb-1 block">Kullanıcı Adınız:</label>
              <Input
                value={currentUser.name}
                onChange={(e) => updateUserName(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <Button
              onClick={() => {
                updateSharedState((state) => ({
                  ...state,
                  pixels: {},
                }))
                setPaintedPixels(new Map())
                sendChatMessage("Tüm pixeller temizlendi! 🧹", "system")
              }}
              variant="secondary"
              size="sm"
              className="w-full bg-red-600 hover:bg-red-700 text-white"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Tüm Boyaları Temizle
            </Button>
            <Button
              onClick={downloadCanvas}
              variant="secondary"
              size="sm"
              className="w-full bg-gray-700 hover:bg-gray-600 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              Haritayı İndir
            </Button>
            <div className="text-white text-xs">
              <p>
                <strong>Gerçek Zamanlı Multiplayer:</strong>
              </p>
              <p>• Eş zamanlı pixel boyama</p>
              <p>• Canlı chat sistemi</p>
              <p>• Yeni sekme açarak test edin!</p>
            </div>
          </div>
        </div>
      )}

      {/* Chat Panel */}
      {chatOpen && (
        <div className="absolute top-16 right-4 bg-gray-800 rounded-lg p-4 z-20 shadow-xl w-80 h-96 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-medium flex items-center gap-2">
              Chat
              <span className="bg-green-500 text-xs px-2 py-1 rounded-full">LIVE</span>
            </h3>
            <Button
              onClick={() => setChatOpen(false)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-gray-700"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          <ScrollArea className="flex-1 mb-3" ref={chatScrollRef}>
            <div className="space-y-2">
              {chatMessages.map((message) => (
                <div
                  key={message.id}
                  className={`p-2 rounded text-sm ${
                    message.type === "system"
                      ? "bg-blue-600 text-white"
                      : message.type === "paint"
                        ? "bg-green-600 text-white"
                        : message.userId === currentUser.id
                          ? "bg-purple-600 text-white"
                          : "bg-gray-700 text-white"
                  }`}
                >
                  <div className="font-semibold text-xs flex items-center gap-1">
                    {message.user}
                    {message.type === "paint" && "🎨"}
                    {message.type === "system" && "🤖"}
                    {message.userId === currentUser.id && " (Sen)"}
                  </div>
                  <div>{message.text}</div>
                  <div className="text-xs text-gray-300 mt-1">{new Date(message.timestamp).toLocaleTimeString()}</div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="flex gap-2">
            <Input
              placeholder="Mesajınızı yazın..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
            />
            <Button onClick={sendMessage} size="sm" className="bg-blue-600 hover:bg-blue-700">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
