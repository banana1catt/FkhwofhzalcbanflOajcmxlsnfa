"use client"

import { useRef, useEffect } from "react"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

export default function Component() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext("2d")
    if (!canvas || !ctx) return

    // Set canvas size
    canvas.width = 800
    canvas.height = 600

    // Clear canvas and set background
    ctx.fillStyle = "#B8D4F0" // Light blue background
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Set continent color
    ctx.fillStyle = "#FFFFFF" // White continents

    // Draw simplified world map continents
    drawContinents(ctx)

    // Draw red border
    ctx.strokeStyle = "#DC2626" // Red border
    ctx.lineWidth = 4
    ctx.strokeRect(2, 2, canvas.width - 4, canvas.height - 4)
  }, [])

  const drawContinents = (ctx: CanvasRenderingContext2D) => {
    // North America
    ctx.beginPath()
    ctx.moveTo(50, 120)
    ctx.lineTo(180, 100)
    ctx.lineTo(220, 140)
    ctx.lineTo(200, 200)
    ctx.lineTo(160, 220)
    ctx.lineTo(120, 200)
    ctx.lineTo(80, 180)
    ctx.lineTo(50, 150)
    ctx.closePath()
    ctx.fill()

    // Greenland
    ctx.beginPath()
    ctx.moveTo(250, 80)
    ctx.lineTo(280, 70)
    ctx.lineTo(290, 100)
    ctx.lineTo(270, 120)
    ctx.lineTo(250, 110)
    ctx.closePath()
    ctx.fill()

    // South America
    ctx.beginPath()
    ctx.moveTo(180, 280)
    ctx.lineTo(220, 260)
    ctx.lineTo(240, 320)
    ctx.lineTo(230, 400)
    ctx.lineTo(200, 420)
    ctx.lineTo(170, 380)
    ctx.lineTo(160, 320)
    ctx.closePath()
    ctx.fill()

    // Europe
    ctx.beginPath()
    ctx.moveTo(320, 120)
    ctx.lineTo(380, 110)
    ctx.lineTo(390, 140)
    ctx.lineTo(370, 160)
    ctx.lineTo(330, 150)
    ctx.closePath()
    ctx.fill()

    // Africa
    ctx.beginPath()
    ctx.moveTo(340, 180)
    ctx.lineTo(420, 170)
    ctx.lineTo(440, 220)
    ctx.lineTo(430, 300)
    ctx.lineTo(400, 350)
    ctx.lineTo(360, 340)
    ctx.lineTo(330, 280)
    ctx.lineTo(320, 220)
    ctx.closePath()
    ctx.fill()

    // Asia
    ctx.beginPath()
    ctx.moveTo(400, 100)
    ctx.lineTo(600, 80)
    ctx.lineTo(650, 120)
    ctx.lineTo(680, 160)
    ctx.lineTo(660, 200)
    ctx.lineTo(620, 180)
    ctx.lineTo(580, 160)
    ctx.lineTo(520, 140)
    ctx.lineTo(450, 130)
    ctx.closePath()
    ctx.fill()

    // India
    ctx.beginPath()
    ctx.moveTo(520, 200)
    ctx.lineTo(560, 190)
    ctx.lineTo(570, 230)
    ctx.lineTo(550, 250)
    ctx.lineTo(520, 240)
    ctx.closePath()
    ctx.fill()

    // China/East Asia
    ctx.beginPath()
    ctx.moveTo(580, 140)
    ctx.lineTo(640, 130)
    ctx.lineTo(660, 170)
    ctx.lineTo(640, 190)
    ctx.lineTo(600, 180)
    ctx.closePath()
    ctx.fill()

    // Australia
    ctx.beginPath()
    ctx.moveTo(620, 320)
    ctx.lineTo(700, 310)
    ctx.lineTo(720, 340)
    ctx.lineTo(710, 360)
    ctx.lineTo(650, 350)
    ctx.closePath()
    ctx.fill()

    // Antarctica
    ctx.beginPath()
    ctx.moveTo(100, 500)
    ctx.lineTo(700, 480)
    ctx.lineTo(720, 520)
    ctx.lineTo(680, 550)
    ctx.lineTo(120, 570)
    ctx.lineTo(80, 540)
    ctx.closePath()
    ctx.fill()

    // Additional islands and details
    // Japan
    ctx.beginPath()
    ctx.arc(680, 160, 8, 0, 2 * Math.PI)
    ctx.fill()

    // UK
    ctx.beginPath()
    ctx.arc(320, 130, 6, 0, 2 * Math.PI)
    ctx.fill()

    // Madagascar
    ctx.beginPath()
    ctx.arc(450, 320, 5, 0, 2 * Math.PI)
    ctx.fill()

    // New Zealand
    ctx.beginPath()
    ctx.arc(740, 380, 4, 0, 2 * Math.PI)
    ctx.fill()
  }

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Dünya Haritası - World Map Canvas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center">
            <canvas
              ref={canvasRef}
              className="border-2 border-red-600 rounded-lg shadow-lg max-w-full h-auto"
              style={{ maxWidth: "100%", height: "auto" }}
            />
          </div>
          <p className="text-sm text-gray-600 mt-4 text-center">Interactive world map drawn on HTML5 Canvas</p>
        </CardContent>
      </Card>
    </div>
  )
}
